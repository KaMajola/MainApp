package poe.MainApp;

/**
 * MainApp.java
 *
 * A simple Java Swing application for user registration, login, and message management.
 *
 * External Libraries:
 * - Gson (https://github.com/google/gson) for JSON handling.
 *
 * Author: [ST10486077]
 * Date: 2025-06-07
 *
 * References:
 * - Java Swing documentation: https://docs.oracle.com/javase/tutorial/uiswing/
 * - SHA-256 hash generation: https://stackoverflow.com/a/55321305
 */
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Represents a user with username, password, and cell number.
 * Provides validation methods for user registration.
 *
 * @author [ST10486077]
 * @version 1.0
 * @since 2024-04-07
 */
class User {
    private final String username;
    private final String password;
    private final String cellNumber;

    /**
     * Constructs a User object.
     *
     * @param username the username
     * @param password the password
     * @param cellNumber the cell number
     */
    public User(String username, String password, String cellNumber) {
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
    }

    /**
     * Gets the username.
     * @return the username
     */
    public String getUsername() { return username; }
    /**
     * Gets the password.
     * @return the password
     */
    public String getPassword() { return password; }
    /**
     * Gets the cell number.
     * @return the cell number
     */
    public String getCellNumber() { return cellNumber; }

    /**
     * Validates if the username is correctly formatted.
     * Username must contain an underscore and be no more than five characters.
     *
     * @param username The username to validate.
     * @return true if valid, false otherwise.
     */
    public static boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Validates if the password is correctly formatted.
     * Password must be at least 8 characters, contain a capital letter, a number, and a special character.
     *
     * @param password The password to validate.
     * @return true if valid, false otherwise.
     */
    public static boolean isValidPassword(String password) {
        if (password.length() < 8) return false;
        if (!password.matches(".*[A-Z].*")) return false;
        if (!password.matches(".*[0-9].*")) return false;
        if (!password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*")) return false;
        return true;
    }

    /**
     * Validates if the cell number is correctly formatted.
     * Cell number must start with +27 and be 9 or 10 digits after the code.
     *
     * @param cell The cell number to validate.
     * @return true if valid, false otherwise.
     */
    public static boolean isValidCellNumber(String cell) {
        return cell.matches("^\\+27\\d{9,10}$");
    }
}

/**
 * Represents a message sent by a user.
 * Handles message ID, hash generation, and validation.
 *
 * @author [ST10486077]
 * @version 1.0
 * @since 2025-05-15
 */
final class Message {
    private static int messageCount = 0;
    private final String messageID;
    private final String recipient;
    private final String messageText;
    private final String messageHash;
    private final String date;
    private final String time;
    private final String flag;

    /**
     * Constructs a Message object.
     *
     * @param recipient the recipient cell number
     * @param messageText the message text
     * @param flag the message flag (Sent, Disregard, Stored)
     */
    public Message(String recipient, String messageText, String flag) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
        LocalDateTime now = LocalDateTime.now();
        this.date = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        this.time = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        this.flag = flag;
        messageCount++;
    }

    /**
     * Generates a random 10-digit message ID.
     *
     * @return the message ID
     */
    private String generateMessageID() {
        return String.format("%010d", new java.util.Random().nextInt(1000000000));
    }

    /**
     * Checks if the recipient cell number is valid.
     *
     * @param cell the cell number
     * @return true if valid, false otherwise
     */
    public static boolean checkRecipientCell(String cell) {
        return User.isValidCellNumber(cell);
    }

    /**
     * Creates a SHA-256 hash for the message.
     * Adapted from: https://stackoverflow.com/a/55321305
     *
     * @return the message hash (first 12 hex characters)
     */
    public String createMessageHash() {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String input = messageID + recipient + messageText + date + time;
            byte[] hash = digest.digest(input.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if(hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString().substring(0, 12); // Shorten for display
        } catch (Exception ex) {
            return "HASH_ERR";
        }
    }

    /**
     * Validates if the message is no more than 250 characters.
     *
     * @param msg the message text
     * @return true if valid, false otherwise
     */
    public static boolean isValidMessage(String msg) {
        return msg.length() <= 250;
    }

    /**
     * Gets the message ID.
     * @return the message ID
     */
    public String getMessageID() { return messageID; }
    /**
     * Gets the recipient cell number.
     * @return the recipient cell number
     */
    public String getRecipient() { return recipient; }
    /**
     * Gets the message text.
     * @return the message text
     */
    public String getMessageText() { return messageText; }
    /**
     * Gets the message hash.
     * @return the message hash
     */
    public String getMessageHash() { return messageHash; }
    /**
     * Gets the date the message was created.
     * @return the date
     */
    public String getDate() { return date; }
    /**
     * Gets the time the message was created.
     * @return the time
     */
    public String getTime() { return time; }
    /**
     * Gets the message flag.
     * @return the flag
     */
    public String getFlag() { return flag; }
    /**
     * Gets the total number of messages created.
     * @return the message count
     */
    public static int getMessageCount() { return messageCount; }
}

/**
 * Main application class for user registration, login, and message management.
 * Uses Java Swing for GUI and Gson for JSON persistence.
 *
 * @author [ST10486077]
 * @version 1.0
 * @since 2025-06-07
 */
public class MainApp {
    private static final String USERS_FILE = "users.json";
    private static final String MESSAGES_FILE = "messages.json";
    private static User currentUser = null;
    private static List<User> users = new ArrayList<>();
    private static List<Message> messages = new ArrayList<>();
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIDs = new ArrayList<>();

    /**
     * Main entry point. Loads users and messages, then shows the main menu.
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        loadUsers();
        loadMessages();
        while (true) {
            String menu = "Main Menu:\n1. Register\n2. Login\n3. Exit\nEnter your choice (1-3):";
            String input = JOptionPane.showInputDialog(menu);
            if (input == null) break;
            switch (input) {
                case "1":
                    registerUser();
                    break;
                case "2":
                    if (loginUser()) {
                        userMenu();
                    }
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    saveUsers();
                    saveMessages();
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please enter 1, 2, or 3.");
            }
        }
    }

    /**
     * Handles user registration with validation and duplicate checking.
     */
    private static void registerUser() {
        String username;
        while (true) {
            username = JOptionPane.showInputDialog("Enter username:");
            if (username == null) return;
            if (User.isValidUsername(username)) {
                JOptionPane.showMessageDialog(null, "Username successfully captured.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        String password;
        while (true) {
            password = JOptionPane.showInputDialog("Enter password:");
            if (password == null) return;
            if (User.isValidPassword(password)) {
                JOptionPane.showMessageDialog(null, "Password successfully captured.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        String cell;
        while (true) {
            cell = JOptionPane.showInputDialog("Enter cell number (e.g. +27839868976):");
            if (cell == null) return;
            if (User.isValidCellNumber(cell)) {
                JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Cell number is incorrectly formatted or does not contain international code, please correct the number and try again.");
            }
        }

        // Check for duplicate username
        for (User u : users) {
            if (u.getUsername().equals(username)) {
                JOptionPane.showMessageDialog(null, "Username already exists. Please choose another.");
                return;
            }
        }

        users.add(new User(username, password, cell));
        saveUsers();
        JOptionPane.showMessageDialog(null, "Registration successful! You can now log in.");
    }

    /**
     * Handles user login and sets the current user if successful.
     * @return true if login successful, false otherwise
     */
    private static boolean loginUser() {
        String username = JOptionPane.showInputDialog("Login - Enter username:");
        if (username == null) return false;
        String password = JOptionPane.showInputDialog("Login - Enter password:");
        if (password == null) return false;

        for (User u : users) {
            if (u.getUsername().equals(username) && u.getPassword().equals(password)) {
                currentUser = u;
                JOptionPane.showMessageDialog(null, "Welcome " + currentUser.getUsername() + ", it is great to see you again.");
                return true;
            }
        }
        JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again.");
        return false;
    }

    /**
     * Shows the user menu and handles user actions after login.
     */
    private static void userMenu() {
        while (true) {
            String menu = "User Menu:\n1. Send Message(s)\n2. View Messages\n3. Display Sender/Recipient of Sent Messages\n4. Display Longest Sent Message\n5. Search for Message by ID\n6. Search Messages by Recipient\n7. Delete Message by Hash\n8. Display Sent Messages Report\n9. Logout\nEnter your choice (1-9):";
            String input = JOptionPane.showInputDialog(menu);
            if (input == null) return;
            switch (input) {
                case "1":
                    sendMessages();
                    break;
                case "2":
                    showAllMessages();
                    break;
                case "3":
                    displaySenderRecipientOfSentMessages();
                    break;
                case "4":
                    displayLongestSentMessage();
                    break;
                case "5":
                    searchMessageByID();
                    break;
                case "6":
                    searchMessagesByRecipient();
                    break;
                case "7":
                    deleteMessageByHash();
                    break;
                case "8":
                    displaySentMessagesReport();
                    break;
                case "9":
                    JOptionPane.showMessageDialog(null, "Logged out.");
                    currentUser = null;
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please enter a number between 1 and 9.");
            }
        }
    }

    /**
     * Handles sending one or more messages, with validation and display of details.
     */
    private static void sendMessages() {
        int numMessages = 0;
        while (true) {
            try {
                String numStr = JOptionPane.showInputDialog("How many messages do you want to send?");
                if (numStr == null) return;
                numMessages = Integer.parseInt(numStr);
                if (numMessages > 0) break;
            } catch (Exception e) {
                // ignore and re-prompt
            }
        }

        for (int i = 0; i < numMessages; i++) {
            String rec;
            while (true) {
                rec = JOptionPane.showInputDialog("Enter recipient cell number (e.g. +27839868976):");
                if (rec == null) return;
                if (Message.checkRecipientCell(rec)) {
                    JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Cell phone number incorrectly formatted or does not contain international code. Please correct the number and try again.");
                }
            }

            String msg;
            while (true) {
                msg = JOptionPane.showInputDialog("Enter message (max 250 chars):");
                if (msg == null) return;
                if (Message.isValidMessage(msg)) {
                    JOptionPane.showMessageDialog(null, "Message ready to send.");
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Message exceeds 250 characters, please reduce size.");
                }
            }

            String flag = "Sent"; // or prompt user for flag if needed
            Message m = new Message(rec, msg, flag);

            // Show message details
            JOptionPane.showMessageDialog(null,
                "Message ID: " + m.getMessageID() +
                "\nRecipient: " + m.getRecipient() +
                "\nMessage: " + m.getMessageText() +
                "\nMessage Hash: " + m.getMessageHash() +
                "\nDate: " + m.getDate() +
                "\nTime: " + m.getTime()
            );

            // Save to JSON
            messages.add(m);
        }
        saveMessages();
        JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.getMessageCount() + "\nMessages saved to JSON file.");
    }

    /**
     * Displays all messages in a scrollable dialog.
     */
    private static void showAllMessages() {
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (Message m : messages) {
            sb.append("Message ID: ").append(m.getMessageID()).append("\n");
            sb.append("Recipient: ").append(m.getRecipient()).append("\n");
            sb.append("Message: ").append(m.getMessageText()).append("\n");
            sb.append("Hash: ").append(m.getMessageHash()).append("\n");
            sb.append("Date: ").append(m.getDate()).append("\n");
            sb.append("Time: ").append(m.getTime()).append("\n");
            sb.append("--------------------------------------------------\n");
            count++;
        }
        if (count == 0) {
            sb.append("No messages found.");
        }
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(600, 400));
        JOptionPane.showMessageDialog(null, scrollPane, "All Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Displays sender and recipient of all sent messages.
     */
    private static void displaySenderRecipientOfSentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages found.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Sender: ").append(currentUser != null ? currentUser.getUsername() : "Unknown")
              .append(", Recipient: ").append(m.getRecipient()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Sender/Recipient of Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Displays the longest sent message.
     */
    private static void displayLongestSentMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages found.");
            return;
        }
        Message longest = sentMessages.get(0);
        for (Message m : sentMessages) {
            if (m.getMessageText().length() > longest.getMessageText().length()) {
                longest = m;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest Sent Message:\n" + longest.getMessageText(), "Longest Message", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Searches for a message by its ID and displays it if found.
     */
    private static void searchMessageByID() {
        String id = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (id == null) return;
        for (Message m : messages) {
            if (m.getMessageID().equals(id)) {
                JOptionPane.showMessageDialog(null, "Recipient: " + m.getRecipient() + "\nMessage: " + m.getMessageText(), "Message Found", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    /**
     * Searches for all messages sent or stored to a particular recipient.
     */
    private static void searchMessagesByRecipient() {
        String rec = JOptionPane.showInputDialog("Enter recipient cell number to search:");
        if (rec == null) return;
        StringBuilder sb = new StringBuilder();
        for (Message m : messages) {
            if (("Sent".equalsIgnoreCase(m.getFlag()) || "Stored".equalsIgnoreCase(m.getFlag())) && m.getRecipient().equals(rec)) {
                sb.append(m.getMessageText()).append("\n");
            }
        }
        if (sb.length() == 0) {
            JOptionPane.showMessageDialog(null, "No messages found for this recipient.");
        } else {
            JOptionPane.showMessageDialog(null, sb.toString(), "Messages for Recipient", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Deletes a message using its hash value.
     */
    private static void deleteMessageByHash() {
        String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
        if (hash == null) return;
        Iterator<Message> it = messages.iterator();
        boolean found = false;
        while (it.hasNext()) {
            Message m = it.next();
            if (m.getMessageHash().equals(hash)) {
                it.remove();
                sentMessages.remove(m);
                disregardedMessages.remove(m);
                storedMessages.remove(m);
                messageHashes.remove(hash);
                messageIDs.remove(m.getMessageID());
                found = true;
                break;
            }
        }
        if (found) {
            saveMessages();
            JOptionPane.showMessageDialog(null, "Message successfully deleted.");
        } else {
            JOptionPane.showMessageDialog(null, "Message hash not found.");
        }
    }

    /**
     * Displays a report listing full details of all sent messages.
     */
    private static void displaySentMessagesReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages found.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message Hash: ").append(m.getMessageHash()).append("\n");
            sb.append("Recipient: ").append(m.getRecipient()).append("\n");
            sb.append("Message: ").append(m.getMessageText()).append("\n");
            sb.append("Date: ").append(m.getDate()).append("\n");
            sb.append("Time: ").append(m.getTime()).append("\n");
            sb.append("---------------------------------------------\n");
        }
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(600, 400));
        JOptionPane.showMessageDialog(null, scrollPane, "Sent Messages Report", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Saves the list of users to a JSON file using Gson.
     */
    private static void saveUsers() {
        try (Writer writer = Files.newBufferedWriter(Paths.get(USERS_FILE))) {
            gson.toJson(users, writer);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving users: " + e.getMessage());
        }
    }

    /**
     * Loads the list of users from a JSON file using Gson.
     */
    private static void loadUsers() {
        try (Reader reader = Files.newBufferedReader(Paths.get(USERS_FILE))) {
            users = gson.fromJson(reader, new TypeToken<List<User>>(){}.getType());
            if (users == null) users = new ArrayList<>();
        } catch (IOException e) {
            users = new ArrayList<>();
        }
    }

    /**
     * Saves the list of messages to a JSON file using Gson.
     */
    private static void saveMessages() {
        try (Writer writer = Files.newBufferedWriter(Paths.get(MESSAGES_FILE))) {
            gson.toJson(messages, writer);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
        }
    }

    /**
     * Loads the list of messages from a JSON file using Gson.
     * Populates sent, disregarded, and stored message lists.
     */
    private static void loadMessages() {
        try (Reader reader = Files.newBufferedReader(Paths.get(MESSAGES_FILE))) {
            messages = gson.fromJson(reader, new TypeToken<List<Message>>(){}.getType());
            if (messages == null) messages = new ArrayList<>();
        } catch (IOException e) {
            messages = new ArrayList<>();
        }

        for (Message m : messages) {
            if ("Sent".equalsIgnoreCase(m.getFlag())) sentMessages.add(m);
            else if ("Disregard".equalsIgnoreCase(m.getFlag())) disregardedMessages.add(m);
            else if ("Stored".equalsIgnoreCase(m.getFlag())) storedMessages.add(m);
            messageHashes.add(m.getMessageHash());
            messageIDs.add(m.getMessageID());
        }
    }
}